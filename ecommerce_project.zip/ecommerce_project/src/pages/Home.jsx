import { Navbar, Product, Footer } from "../components";

function Home() {
  return (
    <>
      <Navbar />
      <Product />
      <Footer />
    </>
  )
}

export default Home